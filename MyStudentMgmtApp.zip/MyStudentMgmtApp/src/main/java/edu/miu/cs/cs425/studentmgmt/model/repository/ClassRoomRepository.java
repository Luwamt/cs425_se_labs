package edu.miu.cs.cs425.studentmgmt.model.repository;

import edu.miu.cs.cs425.studentmgmt.model.model.ClassRoom;
import org.springframework.data.repository.CrudRepository;

public interface ClassRoomRepository extends CrudRepository<ClassRoom, Long> {
}
