package edu.miu.cs.cs425.eregistrarwebapi.exception;

public class MyException extends Exception{

    public MyException(String message) {
        super(message);
    }
}
